
''' ©CopyRight By Uknown Hacker '''

'''importing modul'''

import os
import bsh
import arr

''' Veriables '''

exit = False


os.system("clear")
os.chdir("/storage/emulated/0/")

''' Function Area '''

def main(cmd):
	return os.system(cmd)
	
''' Main Loop '''

while not exit:
	
	
	path = os.getcwd()
	
	
	print("\n")
	cmd = arr.arrow()
	print("\n")
	
	''' Conditions '''
	
	
	if cmd[0:2] == "cd":
		tar = cmd[3:(len(cmd)+1)]
		target = f"{path}/{tar}"
		if os.path.exists(target):
			os.chdir(target)
		else:
			print(f"File Not Found {target}")
	elif cmd == "help":
		print(bsh.help())
	elif cmd == "exit":
		exit = True
	elif cmd == "termux":
		os.chdir("/data/data/com.termux/files/home")
	elif cmd == "sdcard":
		os.chdir("/sdcard")
	elif cmd == "tools":
		os.chdir("/storage/emulated/0/python/tools")
	else:
		main(cmd)