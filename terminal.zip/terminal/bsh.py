def help():
	helpt = '''GNU bash, version 5.0.17(1)-release (arm-unknown-linux-androideabi)
These shell commands are defined internally.  Type `help' to see this list.
Type `help name' to find out more about the function `name'.
Use `info bash' to find out more about the shell in general.
Use `man -k' or `info' to find out more about commands not in this list.

A star (*) next to a name means that the command is disabled.

 job_spec [&]                    history [-c] [-d offset] [n]>
 (( expression ))                if COMMANDS; then COMMANDS; >
 . filename [arguments]          jobs [-lnprs] [jobspec ...] >
 :                               kill [-s sigspec | -n signum>
 [ arg... ]                      let arg [arg ...]
 [[ expression ]]                local [option] name[=value] >
 alias [-p] [name[=value] ... >  logout [n]
 bg [job_spec ...]               mapfile [-d delim] [-n count>
 bind [-lpsvPSVX] [-m keymap] >  popd [-n] [+N | -N]
 break [n]                       printf [-v var] format [argu>
 builtin [shell-builtin [arg .>  pushd [-n] [+N | -N | dir]
 caller [expr]                   pwd [-LP]
 case WORD in [PATTERN [| PATT>  read [-ers] [-a array] [-d d>
 cd [-L|[-P [-e]] [-@]] [dir]    readarray [-d delim] [-n cou>
 command [-pVv] command [arg .>  readonly [-aAf] [name[=value>
 compgen [-abcdefgjksuv] [-o o>  return [n]
 complete [-abcdefgjksuv] [-pr>  select NAME [in WORDS ... ;]>
 compopt [-o|+o option] [-DEI]>  set [-abefhkmnptuvxBCHP] [-o>
 continue [n]                    shift [n]
 coproc [NAME] command [redire>  shopt [-pqsu] [-o] [optname >
 declare [-aAfFgilnrtux] [-p] >  source filename [arguments]
 dirs [-clpv] [+N] [-N]          suspend [-f]
 disown [-h] [-ar] [jobspec ..>  test [expr]
 echo [-neE] [arg ...]           time [-p] pipeline
 enable [-a] [-dnps] [-f filen>  times
 eval [arg ...]                  trap [-lp] [[arg] signal_spe>
 exec [-cl] [-a name] [command>  true
 exit [n]                        type [-afptP] name [name ..>
 export [-fn] [name[=value] ..>  typeset [-aAfFgilnrtux] [-p]>
 false                           ulimit [-SHabcdefiklmnpqrstu>
 fc [-e ename] [-lnr] [first] >  umask [-p] [-S] [mode]
 fg [job_spec]                   unalias [-a] name [name ...]
 for NAME [in WORDS ... ] ; do>  unset [-f] [-v] [-n] [name .>
 for (( exp1; exp2; exp3 )); d>  until COMMANDS; do COMMANDS;>
 function name { COMMANDS ; } >  variables - Names and meanin>
 getopts optstring name [arg]    wait [-fn] [id ...]
 hash [-lr] [-p pathname] [-dt>  while COMMANDS; do COMMANDS;>
 help [-dms] [pattern ...]       { COMMANDS ; }
 
'''
	return helpt