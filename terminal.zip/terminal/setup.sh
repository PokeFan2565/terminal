pkg install python
pkg install ecj dx
python file.py
cp -f terminal.py /data/data/com.termux/files/usr/etc
cp -f bsh.py /data/data/com.termux/files/usr/etc
cp -f arr.py /data/data/com.termux/files/usr/etc
rm -f /data/data/com.termux/files/usr/etc/bash.bashrc
cp -f bash.bashrc /data/data/com.termux/files/usr/etc
cp -f runjava.py /data/data/com.termux/files/usr/etc
cd uninstall
cp -f uninstall.sh /data/data/com.termux/files/usr/etc/uninstall
cp -f bash.bashrc /data/data/com.termux/files/usr/etc/uninstall