rm -f /data/data/com.termux/files/usr/etc/bash.bashrc
cp -f bash.bashrc /data/data/com.termux/files/usr/etc
rm -f /data/data/com.termux/files/usr/etc/terminal.py
rm -f /data/data/com.termux/files/usr/etc/bsh.py
rm -f /data/data/com.termux/files/usr/etc/arr.py
rm -f /data/data/com.termux/files/usr/etc/runjava.py