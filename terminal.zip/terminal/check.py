import os
if os.path.exists("/data/data/com.termux/files/usr/etc/uninstall"):
	if not os.path.exists("/data/data/com.termux/files/usr/etc/uninstall/bash.bashrc"):
		os.system("cp -f bash.bashrc /data/data/com.termux/files/usr/etc/uninstall")
	if not os.path.exists("/data/data/com.termux/files/usr/etc/uninstall/uninstall.sh"):
		os.system("cp -f uninstall.sh /data/data/com.termux/files/usr/etc/uninstall")
else:
	print("False")
		