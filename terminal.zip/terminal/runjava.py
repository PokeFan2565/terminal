
'''
   Make By UknownDevloper

'''

import os

os.chdir("/storage/emulated/0/Android/data")
fpath =	os.getcwd()

if not os.path.exists(f"{fpath}/termux"):
	os.mkdir("termux")
os.chdir(f"{fpath}/termux")
fpath =	os.getcwd()


if not os.path.exists(fpath+"/data.txt"):
	javapath =	input("Set path Enter your Folder Path Only For One Time Where Your Java File Created : ")
	with open(f"{fpath}/data.txt", "w") as f:
		f.write(javapath)


with open(f"{fpath}/data.txt", "r") as f:
	path =	f.read()


os.chdir(path)

os.system("clear")
def ls():
	print("Java Files In Your Folder : ")
	print("\n")
	return os.system("ls")

ls()

name = input("\033[1;93mEnter Java File name Without .java extention : ")

os.system("clear")

os.system(f"ecj {name}.java")
os.system(f"dx --dex --output classes.dex {name.title()}.class")
os.system(f"dalvikvm -cp classes.dex {name.title()}")

