import os

def arrow():
	path = os.getcwd()
	name = "Kali"
	return input(f'''\033[1;95m|~~~\033[1;92m{path}\033[1;95m~~~~[\033[1;91m{name}\033[1;95m]\n|\n|~~~~~>\033[1;92m''')